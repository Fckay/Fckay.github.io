//app.js
App({
  onLaunch: function () {
    // 展示本地存储能力
    wx.cloud.init({
      traceUser: true,

    })
    var logs = wx.getStorageSync('logs') || []
    logs.unshift(Date.now())
    wx.setStorageSync('logs', logs)

    this.globalData = {
    }

    this.loadUserInfo();
  },
//加载缓存用户信息
  loadUserInfo: function(){
    const that = this;
    wx.getSetting({
      success: res =>{
        const isUserInfo = res.authSetting['scope.userInfo'];
        if(isUserInfo){
          wx.getUserInfo({
            success:res =>{
              const userInfo =res.userInfo;
              that.globalData.userInfo = userInfo;
            }
          });
          //获取openid
          wx.cloud.callFunction({
            name: "login",
            success: res => {
              const openId = res.result.openid;
              console.log(openId)
              that.globalData.userInfo.openId = openId;
            }
          })
        }
      }
    })
  },

  is_login: function() {
    this.loadUserInfo();
    if(this.globalData.userInfo){
      return true;
    }else{
      return false;
    }
  },
  //接收用户信息
  setUserInfo: function(userInfo){
    this.globalData = userInfo;
  }
})