//index.js
//获取应用实例
const app = getApp();
const db = wx.cloud.database();

Page({
  /**
   * 页面的初始数据
   */

  data: {
    images: [1,2,3,4,5,6,7,8,9],
    hasmore: true,
    contentList: [],
    dateList: []
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function () {
    this.initImageSize()
    this.loadWrite()
  },

  //刷新加载数据
  loadWrite: function(start=0){
    const that = this
    db.collection("TAAT").skip(start).limit(5).orderBy("create_time","desc").get().then(res => {
      const contentList = res.data;
      let dateList = [];
      let hasmore = true;
      if(contentList.length == 0){
        hasmore = false;
      }
      let newContent = [];
      if(start > 0){
        newContent = that.data.contentList.concat(contentList);
      }else{
        newContent = contentList;
      }
      // for (var i=0;i<newContent.length;i++){
      //   dateList[i] = newContent[i].create_time.toString();
      // }
      newContent.forEach((content,index) =>{
        dateList[index] = content.create_time.toString();
        // content.create_time = content.create_time.getTime()
        // content.isPraised = false;
        // if(content.praises && app.globalData.userInfo.openId){
        //   content.praises.forEach((praise,index) => {
        //     if(prase == app.globalData.userInfo.openId){
        //       content.isPraised = true;
        //     }
        //   })
        // }
      })

      that.setData({
        contentList: newContent,
        hasmore: hasmore,
        dateList: dateList
      });
    }).catch(console.error)
  },

  
  //下拉触发事件
  onPullDownRefresh: function(event){
    this.loadWrite(0);
  },

  //下拉触发事件
  onReachBottom: function(event){
    this.loadWrite(this.data.contentList.length)
  },

  initImageSize: function(){
    const windowwidth =  wx.getSystemInfoSync().windowWidth;
    const twoImageSize = (windowwidth-54-2.5) / 2;
    const threeImageSize = (windowwidth-54-5) / 3;
    this.setData({
      twoImageSize: twoImageSize,
      threeImageSize: threeImageSize
    })
  },

  onImageTap: function(event){
    const dataset = event.target.dataset;
    const contentIndex = dataset.content;
    const imageIndex = dataset.index;
    const images = this.data.contentList[contentIndex].images;
    const current = images[imageIndex];
    wx.previewImage({
      urls: images,
      current: current
    })
  },

  //点赞
  onPraiseTap: function(event){
    const that = this;
    const contentIndex = event.currentTarget.dataset.content;
    const content = that.data.contentList[contentIndex];
    const openId = app.globalData.userInfo.openId;
    let isPraised = false;//判断是否点赞
    if(content.praises){
      content.praises.forEach((value,index) => {
        if(value == openId){
          isPraised = true
        }
      });
    }
    
    if(!isPraised){
      wx.cloud.callFunction({
        name: "praise",
        data: {
          contentId: content._id
        },
        success: res => {
          if(!content.praises){
            content.praises = [openId];
          }else{
            content.praises.push(openId);
          }
          const contentList = that.data.contentList;
          contentList[contentIndex] = content;
          that.setData({
            contentList: contentList
          })
        }
      })
    }

  }
}
)
