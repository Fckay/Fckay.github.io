import { getUUID,getExt} from "../../utils/util.js";
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    tempImages: []
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    const type = options.type;
    const pages = getCurrentPages();
    console.log(pages);
    const indexPage = pages[0];
    const tempImages = indexPage.data.tempImages;
    console.log(type);
    this.setData({
      tempImages: tempImages,
      type: type
    })
    this.initImageSize();
  },

  initImageSize: function(){
    const windowWidth = wx.getSystemInfoSync().windowWidth;
    const containerWitdh = windowWidth - 60;
    const imageSize = (containerWitdh - 2.5*3)/3;
    this.setData({
      imageSize: imageSize
    })
  },

  //发布内容
  onSubmitEvent: function(event){
    wx.showLoading({
      title: '正在发布',
    })
    const that = this;
    const content = event.detail.value.content;
    const author = app.globalData.userInfo;
    const type = this.data.type;
    const tempImages = that.data.tempImages;
    console.log(tempImages);
    let flag = true;
    if(content && tempImages.length < 1){
      console.log("纯文本")
      that.imgCheck([],content,author);
    }
    
    if(tempImages.length > 0){
      const today = new Date();
      const year = today.getFullYear();
      const month = today.getMonth() + 1;
      const day = today.getDate();
      const imagesList = [];
      //上传图片
        tempImages.forEach((value,index)=>{
          wx.getFileSystemManager().readFile({
            filePath: value,
            success: buffer => {
              console.log("上传")
              wx.cloud.uploadFile({
                filePath: value,
                cloudPath: "images/"+year+"/"+month+"/"+day+"/"+getUUID()+"."+getExt(value),
                success:res=>{
                  console.log(buffer.data)
                  // fileIDList.push(res.fileID);
                  imagesList.push({
                    'bufData': buffer.data,
                    'cloudFileID': res.fileID
                  });
                  console.log(imagesList.length)
                  if(imagesList.length == tempImages.length){
                    console.log(imagesList);
                    that.imgCheck(imagesList,content,author);
                  }
                }
                
              })
            }
          })
        })
      
    }
  },

  // //检测内容安全
  // textCheck: function(text,author){
  //   wx.cloud.callFunction({
  //     name: 'ContentCheck',
  //     data: {
  //       txt: text,
  //       author: author
  //     },
  //     success(res){
  //       if(res.result.code != 200){
  //         // flag = false;
  //         wx.showToast({
  //           title: res.result.msg,
  //           icon: 'none'
  //       });
  //       }
  //       else if (res.result.code == 200){
  //         wx.hideLoading()
  //         wx.showToast({
  //           title: '发布成功',
  //         })
  //       }
  //       console.log("没问题")
  //     }
  //   })
  // },

  //检测图片安全
  imgCheck:function(imagesList,content,author){
    const date = new Date() +"";
    console.log(date)
    console.log(imagesList);
    wx.cloud.callFunction({
      name: 'ContentCheck',
      data: {
        value: imagesList,
        txt: content,
        author: author,
        date: date
      },
      success(res) {
        if (res.result.code != 200) {
            wx.showToast({
                title: res.result.msg,
                icon: 'none'
            });
        } else {
          wx.hideLoading()
          wx.showToast({
            title: '发布成功',
            duration: 5000
          })
            //图片正常
           setTimeout(function(){
              wx.reLaunch({
              url: '../index/index'
            })
           },900)
            console.log("正常")
        }
      }
  })
  },

  onAddImageTap: function(event){
    const that = this;
    wx.chooseImage({
      success: function(res){
        const tempImages = res.tempFilePaths;
        const oldImages = that.data.tempImages;
        const newImages = oldImages.concat(tempImages);
        that.setData({
          tempImages: newImages
        })
      }
    })
  },
  onCloseBtnTap: function(even){
    const index = even.target.dataset.index;
    const tempImages = this.data.tempImages;
    tempImages.splice(index,1);
    this.setData({
      tempImages: tempImages
    })
  }
 
})