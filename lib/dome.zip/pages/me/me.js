//logs.js
const app = getApp();
Page({ 
  data: {
    tempImages: []
  } ,

  onLoad: function(options){

  },

  onWrite: function(event) {
    const that = this;
    if(app.is_login()){
      wx.showActionSheet({
        itemList: ['文字','图片','视频'],
        success: res =>{
          const tapIndex = res.tapIndex;
          if(tapIndex == 0){
            wx.navigateTo({
              url: '../write/write?type='+tapIndex,
            })
          }
          else if(tapIndex == 1){
            wx.chooseImage({
              success: function(res){
                const tempImages = res.tempFilePaths;
                that.setData({
                  tempImages: tempImages
                })
                wx.navigateTo({
                  url: '../write/write?type='+tapIndex,
                })
              }
            })
          }
        }
      })
    }else{
      wx.navigateTo({
        url: '../login/login',
      })
    }
  },
  onShareAppMessage: function (res) {
    if (res.from === 'button') {
      console.log(res.target)
    }
    return {
      title: "快来发布你的内容吧",
      path: "/page/index/index",
      imageUrl: '/image/banner1.png'
    }
  },
    contactAdministrator: function() {
      wx.showModal({
        title: '联系邮箱：',
        content: 'jiuyi8@qq.com',
        showCancel: false,
        success(res) {
          if (res.confirm) {
            console.log('用户点击确定')
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
  }
})
