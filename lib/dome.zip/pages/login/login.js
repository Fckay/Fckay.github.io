const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onGetUserInfoTap: function(event){
    const userInfo = event.detail.userInfo;
    if(userInfo){
      app.setUserInfo(userInfo);
      console.log(userInfo);
      console.log(app.is_login());
      wx.showToast({
        title: '授权成功！',
      });
      setTimeout(() =>{
        wx.navigateBack({});
      },1500)
    }
    console.log(app.get);
    console.log(event);
  },
  notGetUserInfoTap: function(){
    wx.showToast({
      title: '未授权！',
      image: '../../images/fail.png'
    });
    setTimeout(() =>{
      wx.navigateBack({});
    },1500)
  }
})