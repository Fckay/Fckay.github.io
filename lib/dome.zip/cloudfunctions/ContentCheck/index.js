// 云函数入口文件
const cloud = require('wx-server-sdk')
cloud.init()
const db = cloud.database();


// 云函数入口函数
exports.main = async (event, context) => {
  // console.log(Object.keys(event.value))
  const {value,txt,author,date} = event;
  // console.log(event.value.cloudFileID)
  let flag = true;
  imagesFileID = [];
  try {
    let result = false;
        //检查图片
        if(value.length > 0){
          console.log("图片")
          for (const key in value) {
            if (value.hasOwnProperty(key)) {
              const element = value[key];
              imagesFileID.push(element.cloudFileID);
              result = await cloud.openapi.security.imgSecCheck({
                media:{
                  contentType: 'image/png',
                  value: Buffer.from(element.bufData)
                }
              })
              if(result.errCode == 87014){
                return {
                  code: 300,
                  msg: '含有违法违规内容',
                  data: result
                }
              }
            }
          }
        }
          console.log(result)
    //检查 文字内容是否违规
    if(txt){
      console.log("文本")
      result = await cloud.openapi.security.msgSecCheck({
        content: txt
      })
    }
    
    //返回结果
    if (result && !flag && result.errCode == 87014) {
      return {
        code: 300,
        msg: '含有违法违规内容',
        data: result
      } //
    } else {
      if(result.errCode == 0){
        // const date = Date() +"";
        await db.collection("TAAT").add({
          data:{
            content: txt,
            author: author,
            images: imagesFileID,
            create_time: db.serverDate()
          }
        })
      }
      return {
        code: 200,
        msg: 'ok',
        data: result
      }
    }  
  } catch (err) {
    //处理错误
    if (err.errCode == 87014) {
      return {
        code: 300,
        msg: '含有违法违规内容',
        data: err
      } 
    }
    console.log(err)
    return{
      code: 400,
      msg: '接口异常'
    }
  }

}