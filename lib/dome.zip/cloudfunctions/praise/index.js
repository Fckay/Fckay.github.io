// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init()
const db = cloud.database();
const _ = db.command;

// 云函数入口函数
exports.main = async (event, context) => {
  const wxContext = cloud.getWXContext()
  const openId = wxContext.OPENID;
  const contentId = event.contentId;

  return await db.collection("TAAT").doc(contentId).update({
    data:{
      "praises": _.push(openId)
    }
  })
}