import request from "@/utils/request";
export function listCourse() {
  return request({
    url: "/course/showCourseList",
    method: "get"
  })
}
export function addCourse(data) {
  return request({
    url: "/course/addCourse_handle",
    method: "post",
    data
  })
}
export function exportExcel(data) {
  return request({
    url: '/course/export',
    method: 'post',
    responseType:"blob",
    data
  })
}
export function showMyCourse() {
  return request({
    url: '/course/showMyCourse',
    method: 'get'
  })
}
export function delCourse(data) {
  return request({
    url: '/course/cancelMyCourse',
    method: 'post',
    data
  })
}