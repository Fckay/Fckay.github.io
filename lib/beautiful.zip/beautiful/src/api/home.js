import request from "@/utils/request"

export function homeData() {
  return request({
    url: "/home/show_home_data",
    method: "post"
  })
}
export function addNew(data) {
  return request({
    url: "/home/addNews_handle",
    method: "post",
    data
  })
}
export function delNews(data) {
  return request({
    url: "/home/delNews_handle",
    method: "post",
    data
  })
}