<template>
  <div class="dashboard-container">
    <div class="dashboard-text">欢迎你： {{ name }}</div>
    <el-row>
      <el-row>
        <el-col :span="6">
          <div class="transition-left">
            <div class="icon">
              <i class="el-icon-date" />
            </div>
          </div>
          <div class="transition-right">
            <el-row>
              <span class="iscpan">现有课程</span>
            </el-row>
            <el-row>
              <span class="ispan">{{ homeData.courses }}</span>
            </el-row>
          </div>
        </el-col>
        <el-col :span="6">
          <div class="transition-left">
            <div class="icon">
              <i class="el-icon-finished" />
            </div>
          </div>
          <div class="transition-right">
            <el-row>
              <span class="iscpan">已报名课程</span>
            </el-row>
            <el-row>
              <span class="ispan">{{ homeData.courseSuccess }}</span>
            </el-row>
          </div>
        </el-col>
        <el-col :span="6">
          <div class="transition-left">
            <div class="icon">
              <i class="el-icon-s-check" />
            </div>
          </div>
          <div class="transition-right">
            <el-row>
              <span class="iscpan">成绩考核</span>
            </el-row>
            <el-row>
              <span class="ispan">优</span>
            </el-row>
          </div>
        </el-col>
        <el-col :span="6">
          <div class="transition-left">
            <div class="icon">
              <i class="el-icon-user" />
            </div>
          </div>
          <div class="transition-right">
            <el-row>
              <span class="iscpan">身份信息</span>
            </el-row>
            <el-row>
              <span class="ispan"> </span>
            </el-row>
          </div>
        </el-col>
      </el-row>
    </el-row>
    <el-row style="margin-top: 16px">
      <el-col :span="6">
        <el-button type="primary" round @click="addgsForm">
          <i class="el-icon-circle-plus-outline"> 新增</i>
        </el-button>
      </el-col>
    </el-row>
    <el-dialog :title="title" :visible.sync="dialogAddgsVisible" @close="closeDialogAddgsVisible">
      <el-form ref="addForm" :model="addForm" :rules="addNewsRole">
        <el-form-item label="新闻标题" :label-width="formLabelWidth" prop="title" class="form-item-margin-bottom">
          <el-input v-model="addForm.title" autocomplete="off" />
        </el-form-item>
        <el-form-item label="新闻内容" :label-width="formLabelWidth" prop="content" class="form-item-margin-bottom">
          <el-input v-model="addForm.content" type="textarea" :rows="8" />
        </el-form-item>
        <el-form-item label="备注" :label-width="formLabelWidth" class="form-item-margin-bottom">
          <el-input v-model="addForm.remark" />
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogAddgsVisible = false">取消</el-button>
        <el-button type="primary" @click="saveAddForm('addForm')">确 定</el-button>
      </div>
    </el-dialog>
    <template>
      <el-table
        ref="multipleTable"
        :data="homeData.news"
        tooltip-effect="dark"
        class="newsContent"
      >
        <el-table-column type="selection" width="55" />
        <el-table-column prop="title" label="标题" width="180" />
        <el-table-column prop="content" label="内容">
          <template slot-scope="scope">
            <span style="white-space:nowrap">{{ scope.row.content }}</span>
          </template>
        </el-table-column>
        <el-table-column
          prop="remark"
          width="180"
          label="备注"
        >
          <template slot-scope="scope">
            <span style="white-space:nowrap;">{{ scope.row.remark }}</span>
          </template>
        </el-table-column>
        <el-table-column
          prop="status"
          label="操作"
          width="180"
          max-height="60px"
        >
          <template slot-scope="scope">
            <el-button type="primary" icon="el-icon-edit" circle @click="editNews(scope.row)" />
            <el-button type="danger" icon="el-icon-delete" circle @click="delNews(scope.row.newId)" />
          </template>
        </el-table-column>
      </el-table>
    </template>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import { homeData, addNew, delNews } from '@/api/home'
export default {
  name: "Index",
  data(){
    const validatorNewsTitle = (rule, value, callback) => {
      if("" == value){
        callback(new Error("标题不能为空"))
      }else{
        callback()
      }
    };
    const validatorNewsContent = (rule, value, callback) => {
      if("" == value){
        callback("新闻内容不能为空")
      }else{
        callback()
      }
    };
    return {
      homeData: '',
      addForm: {
        title: '',
        content: '',
        remark: ''
      },
      title: '',
      dialogAddgsVisible: false,
      formLabelWidth: '80px',
      addNewsRole: {
        title: [
          {
            required: true,
            trigger: "blur",
            validator: validatorNewsTitle
          }
        ],
        content: [
          {
            required: true,
            trigger: "blur",
            validator: validatorNewsContent
          }
        ]
      }
    }
  },
  computed: {
    ...mapGetters({
      name: 'user/userName'
    })
  },
  created() {
    this.getHomeData()
    console.log(this)
  },
  methods: {
    /**
     * 初始化数据
     */
    getHomeData() {
      homeData().then(response => {
        this.homeData = response.result
      })
    },
    closeDialogAddgsVisible(){
      this.$refs.addForm.resetFields()
      this.title = ""
      this.addForm = {
        title: "",
        content: ""
      }
    },
    addgsForm(){
      this.dialogAddgsVisible = true
      this.title = "新增新闻"
    },
    /**
     * 新增新闻
     * @param news
     */
    saveAddForm(news){
      this.$refs[news].validate( valid => {
        if(valid){
          addNew(this.addForm).then(res => {
            this.dialogAddgsVisible = false
            this.$message({
              message: '添加新闻成功',
              type: 'success'
            })
          })
          this.getHomeData()
        }
      })
    },
    /**
     * TODO::未实现修改的接口
     * @param row
     */
    editNews(row){
      this.dialogAddgsVisible = true
      this.title = '修改新闻'
      this.addForm = {
        title: row.title,
        content: row.content,
        remark: row.remark,
      }
    },
    /**
     * 删除新闻 TODO::接口未实现
     * @param newId
     */
    delNews(newId){
      this.$confirm('你确定要删除此新闻吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        delNews({newsId: newId}).then( res => {
          this.$message({
            message: '删除新闻成功',
            type: 'success'
          })
          this.getHomeData()
        })
      }).catch(() => {
        this.$message({
          message: '取消操作',
          type: 'info'
        })
      })
    }
  }
};
</script>
<style lang="scss" scoped>
.dashboard {
  &-container {
    margin: 30px;
    padding: 0;
  }
  &-text {
    font-size: 30px;
    line-height: 46px;
  }
}

.transition-left {
  margin-top: 25px;
  margin-bottom: 10px;
  width: 25%;
  height: 80px;
  border-radius: 4px;
  background-color: rgba(34, 89, 172, 0.733);
  text-align: center;
  color: rgb(255, 255, 255);
  padding: 13px 8px;
  box-sizing: border-box;
  box-shadow: 0 2px 4px rgba(0, 0, 0, .12), 0 0 6px rgba(0, 0, 0, .04);
  float: left;
}
.transition-right{
  margin-top: 25px;
  margin-bottom: 10px;
  width: 30%;
  height: 80px;
  font-size: 13px;
  border-radius: 4px;
  text-align: center;
  color: rgb(0, 0, 0);
  padding: 20px 10px;
  box-sizing: border-box;
  margin-right: 20px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, .12), 0 0 6px rgba(0, 0, 0, .04);
  float: left;
  :hover{
    cursor:pointer;
  }
}
.icon{
  font-size: 50px
}
.iscpan{
  display: block;
  float: left;
  margin-bottom: 10px
}
.ispan{
  float: left;
  font-weight: 600;
}
.newsContent{
  margin-top: 20px;
}
.form-item-margin-bottom{
  margin-bottom: 25px;
}
</style>
