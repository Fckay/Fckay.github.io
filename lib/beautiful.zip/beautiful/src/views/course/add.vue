<template>
  <div class="add-course-container">
    <h2 style="margin-left: 100px">添加课程信息</h2>
    <el-form
      ref="addCourseForm"
      :model="addCourseForm"
      :rules="addCourseFormRules"
      label-width="100px"
    >
      <el-form-item label="课程名称" prop="courseName">
        <el-input v-model="addCourseForm.courseName" ></el-input>
      </el-form-item>
      <el-form-item label="课程安排" prop="courseDate">
        <el-date-picker
          type="dates"
          v-model="addCourseForm.courseDate"
          placeholder="选择一个或多个日期"
          value-format="yyyy-MM-dd HH:mm:ss"
        >
        </el-date-picker>
      </el-form-item>
      <el-form-item label="课程时间" prop="startAndEndTime">
        <el-time-select
          v-model="addCourseForm.courseStartTime"
          placeholder="起始时间"
          :picker-option="{
            start: '09:00',
            step: '00:30',
            end: '19:30',
            format:'HH:mm'
          }"
        />
        <el-time-select
          v-model="addCourseForm.courseEndTime"
          placeholder="结束时间"
          :picker-options="{
            start: '09:00',
            step: '00:30',
            end: '19:30',
            format: 'HH:mm'
          }"
          style="margin-left: 10px;"
        />
      </el-form-item>
      <el-form-item label="报名截止" prop="deadline">
        <el-date-picker
          type="date"
          v-model="addCourseForm.deadline"
          placeholder="报名截止时间"
          value-format="yyyy-MM-dd HH:mm:ss"
        />
      </el-form-item>
      <el-form-item label="最大人数" prop="maxNum">
        <el-input v-model.number="addCourseForm.maxNum" type="number" min="1"></el-input>
      </el-form-item>
      <el-form-item label="授课老师" prop="teacherId">
        <el-autocomplete
          class="inline-input"
          v-model="addCourseForm.teacher"
          value-key="name"
          placeholder="请选择授课老师"
          :fetch-suggestions="querySearch"
          @select="handleSelect"
        />
      </el-form-item>
      <el-form-item label="课程类型" prop="state">
        <el-select v-model="addCourseForm.state" @change="changeStatus">
          <el-option
            v-for="item in options"
            :key="item.value"
            :label="item.label"
            :value="item.value"
          ></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="课程链接" v-show="showUrl" prop="url" ref="cancleValidateUrl">
        <el-input v-model="addCourseForm.url" />
      </el-form-item>
      <el-form-item label="培训教室" v-show="showLable" prop="url" ref="cancleValidateUrl">
        <el-input v-model="addCourseForm.url"/>
      </el-form-item>
      <el-form-item label="课程描述">
        <el-input v-model="addCourseForm.courseDescribe" type="textarea" :rows="5"></el-input>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" @click="onSubmit">立即创建</el-button>
        <el-button type="warning" @click="resetForm">重置</el-button>
        <el-button>返回</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
  import { listUser } from "@/api/user";
  import { addCourse } from "@/api/course";
  export default {
    name: "Add",
    data(){
      const validatorUrl = (rule, value, callback) => {
        if(this.addCourseForm.state == 1){
          if("" == value){
            callback(new Error("请填写课程链接"))
          }
        }else if(this.addCourseForm.state == 2){
          if("" == value){
            callback(new Error("请填写培训教室"))
          }
        }else if(this.addCourseForm.state == ""){
          callback(new Error("参数非法"))
        }
        callback()
        
      }
      const validatorStartEndTime = (rule, value, callback) => {
        if("" == this.addCourseForm.courseStartTime){
          callback(new Error("请选择课程开始时间"))
        }else if("" == this.addCourseForm.courseEndTime){
          callback(new Error("请选择课程结束时间"))
        }else if(this.addCourseForm.courseStartTime > this.addCourseForm.courseEndTime || this.addCourseForm.courseStartTime == this.addCourseForm.courseEndTime ){
          callback(new Error("课程开始时间不能小于或等于课程结束时间"))
        }else{
          callback()
        }
      }
      return {
        addCourseForm: {
          courseName: "",
          courseDate: "",
          courseStartTime: "",
          courseEndTime: "",
          deadline: "",
          courseDescribe: "",
          teacherId: "",
          teacher: "",
          state: "",
          maxNum: "",
          url: ""
        },
        options: [
          {
            label: "线上课程",
            value: 1
          },
          {
            label: "线下课程",
            value: 2
          }
        ],
        showUrl: false,
        showLable: false,
        // 表单验证规则
        addCourseFormRules:{
          courseName:[
            { required: true, message: "请输入课程名称", trigger: "blur" }
          ],
          maxNum: [
            { required: true, message: "请输入最大人数", trigger: "blur"},
            { type: "number", message: "最大人数必须是数字", trigger: "blur"}
          ],
          teacherId:[
            { required: true, message: "请选择授课老师", trigger: "blur" }
          ],
          url: [
            { required: true, trigger:"blur", validator: validatorUrl}
          ],
          startAndEndTime: [
            { required: true, trigger: "blur", validator: validatorStartEndTime }
          ],
          courseDate: [
            { required: true, message: "请选择课程安排", trigger: "blur" }
          ],
          deadline: [
            { required: true, message: "请选择课程报名截止时间", trigger: "blur" }
          ],
          state: [
            { required: true, message: "请选择课程类型",trigger: "change"}
          ]
        },
        restaurants: []
      }
    },
    mounted(){
      /**
       * 授课老师列表
       */
      listUser().then(res => {
        res.result.map(item => {
          this.restaurants.push({
            name: item.userName + "(" + item.employeeNumber + ")",
            value: item.userId
          })
        })
      })
    },
    methods: {
      /**
       * autocomplete
       * @param queryString
       * @param cb
       */
      querySearch(queryString, cb) {
        let restaurants = this.restaurants;
        let results = queryString ? restaurants.filter(this.createFilter(queryString)) : restaurants;
        // 调用 callback 返回建议列表的数据
        cb(results);
      },
      createFilter(queryString) {
        return (restaurant) => {
          return (restaurant.name.toLowerCase().indexOf(queryString.toLowerCase()) === 0);
        };
      },
      handleSelect(item) {
        this.addCourseForm.teacherId = item.value
        this.addCourseForm.teacher = item.name
      },
      /**
       * 改变课程属性，显示不同的输入框
       */
      changeStatus(){
       this.$refs.cancleValidateUrl.clearValidate() //切换线上线下课程时，清除表单验证的结果
        if(this.addCourseForm.state == 1){
          this.showUrl = true
          this.showLable = false
        }else{
          this.showUrl = false
          this.showLable = true
        }
      },
      /**
       * 表单提交
       */
      onSubmit(){
        this.$refs.addCourseForm.validate(valid => {
          if(valid){
            this.$confirm("你确定要添加此课程吗?", "提示", {
              confirmButtonText: "确定",
              cancelButtonText: "取消",
              type: "warning"
            }).then(() => {
              console.log(this.addCourseForm)
              addCourse(this.addCourseForm).then(res => {
                this.$message({
                  type: "success",
                  message: "添加课程成功"
                })
              }).catch(() => {
                this.$message({
                  type: "error",
                  message: "添加课程失败"
                })
              })
            })
          }
        })
      },
      /**
       * 重置表单
       */
      resetForm(){
        this.$refs.addCourseForm.resetFields();
      }
    }
  }
</script>

<style lang="scss"  scoped>
  .add-course-container{
    width: 60%;
  }
</style>