<template>
  <div class="app-container">
    <el-row :gutter="20">
      <el-col :span="6">
        <el-button type="warning" size="small" icon="el-icon-plus" @click="addCourse">添加课程</el-button>
        <el-button type="success" size="small" icon="el-icon-download" @click="exportExcel">导出Excel</el-button>
      </el-col>
      <el-col :span="4" :offset="12">
        <el-input placeholder="课程名/授课老师" v-model="search"></el-input>
      </el-col>
      <el-col :span="2">
        <el-button type="primary" size="small" icon="el-icon-search" @click="searchCourse">查询</el-button>
      </el-col>
    </el-row>
    <el-table :data="classList" border style="margin-top: 20px" v-loading="listLoading">
      <el-table-column label="序号" align="center" width="95">
        <template slot-scope="scope">{{ scope.$index + 1 }}</template>
      </el-table-column>
      <el-table-column label="课程名" align="center" width="180">
        <template slot-scope="scope">
          <a @click="courseDetails(scope.row.courseId)">{{ scope.row.courseName }}</a>
        </template>
      </el-table-column>
      <el-table-column label="课程描述">
        <template slot-scope="scope">
          <span style="white-space:nowrap;">{{ scope.row.courseDescribe }}</span>
        </template>
      </el-table-column>
      <el-table-column label="授课讲师" align="center">
        <template slot-scope="scope">
          <span>{{ scope.row.u_userName }}</span>
        </template>
      </el-table-column>
      <el-table-column label="已报名人数" align="center">
        <template slot-scope="scope">
          <span>{{ scope.row.hasNum }}人</span>
        </template>
      </el-table-column>
      <el-table-column label="计划人数" align="center">
        <template slot-scope="scope">
          <span>{{ scope.row.maxNum }}人</span>
        </template>
      </el-table-column>
      <el-table-column label="报名截止日期" align="center">
        <template slot-scope="scope">
          <i class="el-icon-time" />
          <span> {{ scope.row.deadline }}</span>
        </template>
      </el-table-column>
      <el-table-column label="课程开始日期" align="center">
        <template slot-scope="scope">
          <i class="el-icon-time" />
          <span> {{ scope.row.courseStartDate }}</span>
        </template>
      </el-table-column>
      <el-table-column label="课程结束日期" align="center">
        <template slot-scope="scope">
          <i class="el-icon-time" />
          <span> {{ scope.row.courseEndDate }}</span>
        </template>
      </el-table-column>
      <el-table-column label="课程类型" align="center">
        <template slot-scope="scope">
          <span>{{ scope.row.state | statusFormat }}</span>
        </template>
      </el-table-column>
      <el-table-column label="操作" align="center">
        <template slot-scope="scope">
          <el-button v-if="scope.row.uc_status == 3" disabled>不可选</el-button>
          <el-button v-else-if="scope.row.uc_status == 2">已选</el-button>
          <el-button v-else type="primary" @click="elective(scope.row.courseId, scope.row.courseName)">选课</el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-pagination
      :background="background"
      :current-page="queryForm.pageNo"
      :layout="layout"
      :page-size="queryForm.pageSize"
      :total="total"
      @current-change="handleCurrentChange"
      @size-change="handleSizeChange"
    ></el-pagination>
  </div>
</template>

<script>
  import {
    listCourse,
    exportExcel
  } from "@/api/course"
  export default {
    name: "Index",
    data(){
      return {
        classList: [],
        background: true,
        listLoading: true,
        search: "",
        /**
         * 分页设置
         */
        queryForm: {
          pageNo: 1,//当前分页
          pageSize: 20,//每页多少数据
        },
        layout: "total, sizes, prev, pager, next, jumper",//分页样式设置
        total: 10,//TODO::数据总数没有接口返回
      }
    },
    filters: {
      /**
       * 课程类型设置
       */
      statusFormat(data){
        if (data == 1) {
          return "线上课程";
        } else if (data == 2) {
          return "线下课程";
        }
      }
    },
    created() {
      this.fetchData()
    },
    methods: {
      /**
       * 获取所有的课程
       */
      fetchData(){
        this.listLoading = true
        listCourse().then(res => {
          this.listLoading = false
          this.classList = res.result
        })
      },
      /**
       * 添加课程
       */
      addCourse(){
        this.$router.push({
          name: "AddCourse"
        })
      },
      /**
       * 导出excel
       */
      exportExcel(){
        this.$confirm("确定导出Excel吗？", "确认选课", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        }).then(() => {
          exportExcel().then(res => {
            console.log(res);
            const blob =new Blob([res], {
              type: "application/vnd.ms-excel;charset=utf-8"
            })
            const url = window.URL.createObjectURL(blob)
            const link = document.createElement("a")
            link.href = url
            link.setAttribute("download", "课程信息一览.xlsx")
            link.click()
            window.URL.revokeObjectURL(link.href)
          }).catch(() => {
            this.$message({
              type: "error",
              message: "导出Excel失败"
            })
          })
        })
      },
      /**
       * 课程详情
       * @param courseId
       */
      courseDetails(courseId){

      },
      /**
       * 选课
       * @param courseId
       * @param courseName
       */
      elective(courseId, courseName){
      
      },
      /**
       * 切换分页
       */
      handleCurrentChange(val){
        this.queryForm.pageNo = val
        // TODO::分页接口没有实现
        this.fetchData()
      },
      /**
       * 改变pageSize后调用
       */
      handleSizeChange(val){
        this.queryForm.pageSize = val
        // TODO::分页接口没有实现
        this.fetchData()
      },
      /**
       * 搜索课程
       */
      searchCourse(){
        // TODO:: 课程搜索接口没有实现
        this.fetchData()
      }
    },
  }
</script>

<style scoped>

</style>