<template>
  <div class="app-container">
    <el-row :gutter="20">
      <el-col :span="4" :offset="18">
        <el-input placeholder="课程名/授课老师" v-model="search"></el-input>
      </el-col>
      <el-col :span="2">
        <el-button type="primary" size="small" icon="el-icon-search" @click="searchCourse">查询</el-button>
      </el-col>
    </el-row>
    <el-table :data="myCourse" border style="margin-top: 20px" v-loading="listLoading">
      <el-table-column label="课程时间" align="center" sortable prop="courseStartDate">
      </el-table-column>
      <el-table-column label="课程名" width="180" align="left">
        <template slot-scope="scope">
          <el-popover trigger="hover" placement="top" align="center">
            <p>课程: {{ scope.row.courseName }}</p>
            <p>简介: {{ scope.row.courseDescribe }}</p>
            <p>课时: {{ scope.row.classHourCount }}</p>
            <div slot="reference" class="name-wrapper">
              <el-tag size="medium">{{ scope.row.courseName }}</el-tag>
            </div>
          </el-popover>
        </template>
      </el-table-column>
      <el-table-column label="授课老师" prop="u_userName" align="center" />
      <el-table-column label="状态" align="center">
        <template slot-scope="scope">{{ scope.row.status | statusFormat }}</template>
      </el-table-column>
      <el-table-column label="操作" align="center">
        <template slot-scope="scope">
          <el-button
            size="mini"
            type="danger"
            :disabled="scope.row.status!=2"
            @click="handleDelete( scope.row)"
          ><i class="el-icon-delete" /></el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-pagination
      :background="background"
      :current-page="queryForm.pageNo"
      :layout="layout"
      :page-size="queryForm.pageSize"
      :total="total"
      @current-change="handleCurrentChange"
      @size-change="handleSizeChange"
    ></el-pagination>
  </div>
</template>

<script>
  import {
    showMyCourse,
    delCourse
  } from "@/api/course"
  export default {
    name: "MyCourse",
    data(){
      return {
        myCourse: [],
        queryForm: {
          pageNo: 1,//当前分页
          pageSize: 20,//每页多少数据
        },
        listLoading: false,
        search: '',
        background: true,
        total: 10,//TODO::数据总数没有接口返回
        layout: "total, sizes, prev, pager, next, jumper"
      }
    },
    filters: {
      statusFormat: function(data) {
        if (data === '1') {
          return '                                                                                                                               '
        }
        if (data === '2') {
          return '已报名'
        }
        if (data === '3') {
          return '未通过'
        }
        if (data === '4') {
          return '审批中'
        }
      }
    },
    created() {
      this.getCourselist()
    },
    methods: {
      handleDelete(row) {
        this.$confirm('你确定要取消此课程吗?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        })
          .then(() => {
            this.listLoading = true
            delCourse(row).then(response => {
              this.listLoading = false
              this.$message({ type: 'info', message: '课程取消成功' })
              this.getCourselist()
            })
          })
          .catch(() => {
            this.$message({ type: 'info', message: '取消操作' })
          })
      },
      getCourselist() {
        showMyCourse().then(response => {
          this.myCourse = response.result
          this.listLoading = false
        })
      },
      handleCurrentChange(val){
        this.queryForm.pageNo = val
        // TODO::分页接口没有实现
        this.getCourselist()
      },
      handleSizeChange(val){
        this.queryForm.pageSize = val
        // TODO::分页接口没有实现
        this.getCourselist()
      },
      searchCourse(){
        // TODO:: 课程搜索接口没有实现
        this.getCourselist()
      }
    }
  }
</script>

<style scoped>

</style>